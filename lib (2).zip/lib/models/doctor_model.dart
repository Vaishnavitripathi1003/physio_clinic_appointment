class DoctorModel {
  final int? id;
  final String name;
  final String? gender;
  final String? specialization;
  final String? phone;
  final String? email;
  final int? experience;
  final String? availability;
  final double? fee;
  final String? clinicName;
  final String? regNo;
  final String? createdAt;

  // Initialize with a dummy doctor to simulate a logged-in state for the dashboard
 /* DoctorModel? _currentDoctor = DoctorModel(
    id: 1,
    name: 'Dr. Meera Kapoor',
    specialization: 'Cardiologist',
    phone: '9876543210',
    email: 'meera.kapoor@clinic.com',
    experience: 12,
    fee: 800.0,
    clinicName: 'Sunrise Clinic',
    regNo: 'DMC-123456', // Used for DMC Registration in the drawer/header
  );*/
  DoctorModel({
    this.id,
    required this.name,
    this.gender,
    this.specialization,
    this.phone,
    this.email,
    this.experience,
    this.availability,
    this.fee,
    this.clinicName,
    this.regNo,
    this.createdAt,
  });

  // 1. ✅ Convert to Map (for inserting into DB)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'gender': gender,
      'specialization': specialization,
      'phone': phone,
      'email': email,
      'experience': experience,
      'availability': availability,
      'fee': fee,
      'clinicName': clinicName,
      'regNo': regNo,
      'createdAt': createdAt ?? DateTime.now().toIso8601String(),
    };
  }

  // 2. ✅ Create instance from DB Map
  factory DoctorModel.fromMap(Map<String, dynamic> map) {
    return DoctorModel(
      id: map['id'] as int?,
      name: map['name'] as String? ?? '', // Ensure name is never null
      gender: map['gender'] as String?,
      specialization: map['specialization'] as String?,
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      experience: map['experience'] is int
          ? map['experience'] as int?
          : int.tryParse(map['experience']?.toString() ?? ''),
      availability: map['availability'] as String?,
      fee: map['fee'] != null ? (map['fee'] as num).toDouble() : null,
      clinicName: map['clinicName'] as String?,
      regNo: map['regNo'] as String?,
      createdAt: map['createdAt'] as String?,
    );
  }

  // 3. ✨ New: Utility method for creating a modified copy
  DoctorModel copyWith({
    int? id,
    String? name,
    String? gender,
    String? specialization,
    String? phone,
    String? email,
    int? experience,
    String? availability,
    double? fee,
    String? clinicName,
    String? regNo,
    String? createdAt,
  }) {
    return DoctorModel(
      id: id ?? this.id,
      name: name ?? this.name,
      gender: gender ?? this.gender,
      specialization: specialization ?? this.specialization,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      experience: experience ?? this.experience,
      availability: availability ?? this.availability,
      fee: fee ?? this.fee,
      clinicName: clinicName ?? this.clinicName,
      regNo: regNo ?? this.regNo,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  // 4. ✨ New: Basic validation check
  bool isValid() {
    // Check if required fields are present and not empty
    return name.isNotEmpty && specialization != null && specialization!.isNotEmpty && regNo != null && regNo!.isNotEmpty;
  }

  // 5. ✅ For easy debugging
  @override
  String toString() {
    return 'DoctorModel(id: $id, name: $name, specialization: $specialization, fee: $fee)';
  }
}