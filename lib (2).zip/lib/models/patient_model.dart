class PatientModel {
  int? id;
  int doctorId;
  String name;
  String? gender;
  int? age;
  String? phone;
  String? email;
  String? bloodGroup;
  String? maritalStatus;
  String? address;
  String? conditionType;
  String? disease;
  String? notes;
  String? createdAt;

  PatientModel({this.id, required this.doctorId, required this.name, this.gender, this.age, this.phone, this.email, this.bloodGroup, this.maritalStatus, this.address, this.conditionType, this.disease, this.notes, this.createdAt});

  Map<String, dynamic> toMap() => {
    'id': id,
    'doctorId': doctorId,
    'name': name,
    'gender': gender,
    'age': age,
    'phone': phone,
    'email': email,
    'bloodGroup': bloodGroup,
    'maritalStatus': maritalStatus,
    'address': address,
    'conditionType': conditionType,
    'disease': disease,
    'notes': notes,
    'createdAt': createdAt,
  };

  factory PatientModel.fromMap(Map<String, dynamic> m) => PatientModel(
    id: m['id'],
    doctorId: m['doctorId'],
    name: m['name'],
    gender: m['gender'],
    age: m['age'],
    phone: m['phone'],
    email: m['email'],
    bloodGroup: m['bloodGroup'],
    maritalStatus: m['maritalStatus'],
    address: m['address'],
    conditionType: m['conditionType'],
    disease: m['disease'],
    notes: m['notes'],
    createdAt: m['createdAt'],
  );
}
