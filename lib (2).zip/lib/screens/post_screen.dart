import 'package:flutter/material.dart';

// --- 1. Data Model & Constants ---

// Enum for video source selection
enum VideoSourceType { url, gallery, record }

class Post {
  final String id;
  final String title;
  final String description;
  final String videoUrl; // Link to the resource (can be external URL or a local file identifier)
  final String category;
  final String author;
  final int views;

  Post({
    required this.id,
    required this.title,
    required this.description,
    required this.videoUrl,
    required this.category,
    required this.author,
    required this.views,
  });
}

// Mock Data for the Feed
final List<Post> mockPosts = [
  Post(
    id: 'P001',
    title: 'Anatomy of the Rotator Cuff',
    description: 'Detailed video explaining the structure and function of the four rotator cuff muscles.',
    videoUrl: 'https://youtube.com/rc_anatomy',
    category: 'Anatomy',
    author: 'Dr. Jane Smith',
    views: 450,
  ),
  Post(
    id: 'P002',
    title: 'Post-Surgical Knee Rehab Protocol',
    description: 'A 6-week guide to physiotherapy exercises following ACL reconstruction.',
    videoUrl: 'https://vimeo.com/acl_rehab',
    category: 'Physiotherapy',
    author: 'PT. Mark Johnson',
    views: 1200,
  ),
  Post(
    id: 'P003',
    title: 'Understanding Hypertension Medication',
    description: 'Review of common ACE inhibitors and Beta-blockers for practitioners.',
    videoUrl: 'https://medtube.com/htn_drugs',
    category: 'Pharmacology',
    author: 'Dr. Alex Lee',
    views: 80,
  ),
];

// --- 2. Main Stateful Widget: Posts Screen ---
class PostsScreen extends StatefulWidget {
  const PostsScreen({super.key});

  @override
  State<PostsScreen> createState() => _PostsScreenState();
}

class _PostsScreenState extends State<PostsScreen> {
  List<Post> _currentPosts = mockPosts;

  void _addNewPost(Post newPost) {
    setState(() {
      _currentPosts = [newPost, ..._currentPosts];
    });
    Navigator.of(context).pop(); // Close the modal
  }

  void _openNewPostModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(
        padding: MediaQuery.of(context).viewInsets,
        child: _NewPostModal(onPostCreated: _addNewPost),
      ),
    );
  }

  Widget _buildPostCard(Post post) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Simulated Video Thumbnail/Preview Area
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 200,
                decoration: BoxDecoration(
                  color: post.category == 'Physiotherapy' ? Colors.teal.shade100 : Colors.indigo.shade100,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                ),
                child: Center(
                  child: Icon(
                    Icons.play_circle_fill,
                    size: 70,
                    color: Colors.black.withOpacity(0.7),
                  ),
                ),
              ),
              // Category Tag
              Positioned(
                top: 10,
                right: 10,
                child: Chip(
                  label: Text(post.category, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                  backgroundColor: post.category == 'Physiotherapy' ? Colors.teal.shade600 : Colors.indigo.shade600,
                ),
              ),
            ],
          ),

          // Post Details
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  post.title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo),
                ),
                const SizedBox(height: 4),
                Text(
                  post.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.grey.shade700),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Author: ${post.author}', style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 13)),
                    Row(
                      children: [
                        const Icon(Icons.visibility, size: 16, color: Colors.grey),
                        const SizedBox(width: 4),
                        Text('${post.views} views', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('💡 Educational Feed'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        itemCount: _currentPosts.length,
        itemBuilder: (context, index) {
          return _buildPostCard(_currentPosts[index]);
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openNewPostModal,
        label: const Text('Add New Post'),
        icon: const Icon(Icons.video_call),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
    );
  }
}


// --- 3. New Post Creation Modal (Updated) ---
class _NewPostModal extends StatefulWidget {
  final Function(Post) onPostCreated;
  const _NewPostModal({required this.onPostCreated});

  @override
  State<_NewPostModal> createState() => _NewPostModalState();
}

class _NewPostModalState extends State<_NewPostModal> {
  final _formKey = GlobalKey<FormState>();
  String _title = '';
  String _description = '';
  String _author = 'Guest Contributor';
  String _category = 'Physiotherapy';

  // State for video source
  VideoSourceType _sourceType = VideoSourceType.url;
  String? _videoSourceIdentifier; // Stores URL or a mock file path

  final List<String> _categories = ['Physiotherapy', 'Anatomy', 'Pharmacology', 'General Medical'];

  void _submitPost() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      // Ensure a video source is selected/provided
      String finalVideoUrl = 'N/A';
      if (_sourceType == VideoSourceType.url && _videoSourceIdentifier == null) {
        // Validation handled by TextFormField, but safe check here
        return;
      } else if (_videoSourceIdentifier != null) {
        finalVideoUrl = _videoSourceIdentifier!;
      } else if (_sourceType != VideoSourceType.url) {
        // Show error if user selected Gallery/Record but didn't 'select' anything
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please select or record a video before posting.')),
        );
        return;
      }

      final newPost = Post(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: _title,
        description: _description,
        videoUrl: finalVideoUrl,
        category: _category,
        author: _author,
        views: 0,
      );

      widget.onPostCreated(newPost);
    }
  }

  // Helper to build the source selection chips
  Widget _buildSourceChip(VideoSourceType type, String label, IconData icon) {
    final isSelected = _sourceType == type;
    return ChoiceChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18),
          const SizedBox(width: 6),
          Text(label),
        ],
      ),
      selected: isSelected,
      selectedColor: Colors.teal.shade300,
      backgroundColor: Colors.grey.shade200,
      labelStyle: TextStyle(
        color: isSelected ? Colors.teal.shade900 : Colors.grey.shade700,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
      onSelected: (selected) {
        if (selected) {
          setState(() {
            _sourceType = type;
            _videoSourceIdentifier = null; // Reset identifier when changing source type
          });
        }
      },
    );
  }

  // Helper to build the conditional input widget
  Widget _buildSourceInput() {
    switch (_sourceType) {
      case VideoSourceType.url:
        return TextFormField(
          decoration: const InputDecoration(labelText: 'External Video URL', prefixIcon: Icon(Icons.link)),
          validator: (value) => value!.isEmpty ? 'Please provide a valid link.' : null,
          onSaved: (value) => _videoSourceIdentifier = value!,
        );

      case VideoSourceType.gallery:
      case VideoSourceType.record:
        return _buildFilePickerPlaceholder(
          _sourceType == VideoSourceType.gallery ? 'Choose Video from Gallery' : 'Record New Video',
          _sourceType == VideoSourceType.gallery ? Icons.folder_open : Icons.videocam_sharp,
          _videoSourceIdentifier,
        );
    }
  }

  // Placeholder widget for Gallery/Record functionality
  Widget _buildFilePickerPlaceholder(String buttonText, IconData icon, String? selectedFile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Video File:',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () {
                  // --- Actual file/camera logic goes here ---
                  // For simulation: set a mock file name
                  String mockFileName = _sourceType == VideoSourceType.gallery
                      ? 'gallery_video_${DateTime.now().second}.mp4'
                      : 'recording_${DateTime.now().second}.mp4';

                  setState(() {
                    _videoSourceIdentifier = mockFileName;
                  });

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Simulated ${_sourceType == VideoSourceType.gallery ? 'selection' : 'recording'} of "$mockFileName"')),
                  );
                },
                icon: Icon(icon),
                label: Text(selectedFile != null ? 'Change Selection' : buttonText),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo.shade50,
                  foregroundColor: Colors.indigo.shade700,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        // Display selected file name
        Text(
          selectedFile != null ? 'Selected: $selectedFile' : 'No file chosen.',
          style: TextStyle(color: selectedFile != null ? Colors.teal.shade800 : Colors.red, fontStyle: FontStyle.italic),
        ),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(25.0)),
        boxShadow: [
          BoxShadow(blurRadius: 10, color: Colors.black.withOpacity(0.2)),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Submit Educational Content',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold, color: Colors.indigo),
              ),
              const Divider(height: 20),

              // --- 1. Content Source Selection (New) ---
              const Text(
                'Video Source:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8.0,
                children: [
                  _buildSourceChip(VideoSourceType.url, 'External URL', Icons.link),
                  _buildSourceChip(VideoSourceType.gallery, 'Gallery', Icons.collections),
                  _buildSourceChip(VideoSourceType.record, 'Record', Icons.videocam),
                ],
              ),
              const SizedBox(height: 20),

              // --- 2. Conditional Video Input (New) ---
              _buildSourceInput(),
              const SizedBox(height: 25),

              // --- 3. Remaining Fields ---
              TextFormField(
                decoration: const InputDecoration(labelText: 'Video Title', prefixIcon: Icon(Icons.title)),
                validator: (value) => value!.isEmpty ? 'Please enter a title.' : null,
                onSaved: (value) => _title = value!,
              ),
              const SizedBox(height: 15),

              TextFormField(
                decoration: const InputDecoration(labelText: 'Short Description', prefixIcon: Icon(Icons.description)),
                maxLines: 3,
                validator: (value) => value!.isEmpty ? 'Please enter a description.' : null,
                onSaved: (value) => _description = value!,
              ),
              const SizedBox(height: 25),

              // Category Dropdown
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  prefixIcon: Icon(Icons.category),
                  border: OutlineInputBorder(),
                ),
                items: _categories.map((String category) {
                  return DropdownMenuItem<String>(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _category = newValue!;
                  });
                },
              ),
              const SizedBox(height: 30),

              // Submit Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _submitPost,
                  icon: const Icon(Icons.send),
                  label: const Text('Post Content', style: TextStyle(fontSize: 16)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal.shade600,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }
}