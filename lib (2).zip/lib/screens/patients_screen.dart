import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/patient_provider.dart';
import '../providers/auth_provider.dart';
import '../models/patient_model.dart';

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({super.key});

  @override
  State<PatientsScreen> createState() => _PatientsScreenState();
}

class _PatientsScreenState extends State<PatientsScreen> {
  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    if (auth.currentDoctor != null) {
      Provider.of<PatientProvider>(context, listen: false)
          .loadPatientsForDoctor(auth.currentDoctor!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final pProv = Provider.of<PatientProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Patients'),
        backgroundColor: const Color(0xFF0FAF7C),
      ),
      body: FutureBuilder(
        future: pProv.loadPatientsForDoctor(auth.currentDoctor?.id ?? -1),
        builder: (context, snap) {
          final patients = pProv.patients;
          if (patients.isEmpty) {
            return const Center(child: Text('No patients yet'));
          }
          return ListView.builder(
            itemCount: patients.length,
            itemBuilder: (context, i) {
              final p = patients[i];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(p.name),
                  subtitle: Text(
                      '${p.disease ?? ''} • ${p.age != null ? '${p.age} yrs' : ''}'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (s) async {
                      if (s == 'delete') await pProv.deletePatient(p.id!);
                      if (s == 'edit') _showEdit(context, pProv, p);
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0FAF7C),
        child: const Icon(Icons.add),
        onPressed: () {
          final auth = Provider.of<AuthProvider>(context, listen: false);
          _showAdd(context, Provider.of<PatientProvider>(context, listen: false),
              auth.currentDoctor!.id!);
        },
      ),
    );
  }

  // 🧩 Add Patient
  void _showAdd(BuildContext context, PatientProvider prov, int doctorId) {
    final _form = GlobalKey<FormState>();
    final _name = TextEditingController();
    String gender = 'Female';
    final _age = TextEditingController();
    final _phone = TextEditingController();
    final _disease = TextEditingController();
    String blood = 'O+';
    String marital = 'Single';
    final _notes = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => AnimatedPadding(
        duration: const Duration(milliseconds: 300),
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(
          builder: (ctx, setState) {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _form,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Add Patient',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: _name,
                        decoration:
                        const InputDecoration(labelText: 'Full name'),
                        validator: (v) =>
                        v == null || v.trim().isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _age,
                              decoration:
                              const InputDecoration(labelText: 'Age'),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextFormField(
                              controller: _phone,
                              decoration:
                              const InputDecoration(labelText: 'Phone'),
                              keyboardType: TextInputType.phone,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: _disease,
                        decoration: const InputDecoration(
                            labelText: 'Disease / Problem'),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: blood,
                              items: [
                                'O+',
                                'A+',
                                'B+',
                                'AB+',
                                'O-',
                                'A-',
                                'B-',
                                'AB-'
                              ]
                                  .map((e) => DropdownMenuItem(
                                  value: e, child: Text(e)))
                                  .toList(),
                              onChanged: (v) => setState(() => blood = v!),
                              decoration: const InputDecoration(
                                  labelText: 'Blood Group'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: marital,
                              items: ['Single', 'Married', 'Other']
                                  .map((e) => DropdownMenuItem(
                                  value: e, child: Text(e)))
                                  .toList(),
                              onChanged: (v) => setState(() => marital = v!),
                              decoration: const InputDecoration(
                                  labelText: 'Marital Status'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      const Align(
                        alignment: Alignment.centerLeft,
                        child: Text('Gender',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                      ),
                      Column(
                        children: ['Female', 'Male', 'Other']
                            .map(
                              (g) => RadioListTile<String>(
                            title: Text(g),
                            value: g,
                            groupValue: gender,
                            onChanged: (v) =>
                                setState(() => gender = v!),
                          ),
                        )
                            .toList(),
                      ),
                      TextFormField(
                        controller: _notes,
                        decoration:
                        const InputDecoration(labelText: 'Notes'),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.save),
                        onPressed: () async {
                          if (!_form.currentState!.validate()) return;
                          final p = PatientModel(
                            doctorId: doctorId,
                            name: _name.text.trim(),
                            gender: gender,
                            age: int.tryParse(_age.text.trim()),
                            phone: _phone.text.trim(),
                            disease: _disease.text.trim(),
                            bloodGroup: blood,
                            maritalStatus: marital,
                            notes: _notes.text.trim(),
                            createdAt: DateTime.now().toIso8601String(),
                          );
                          await prov.addPatient(p);
                          Navigator.pop(ctx);
                        },
                        label: const Text('Save'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF0FAF7C),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // 🧩 Edit Patient
  void _showEdit(BuildContext context, PatientProvider prov, PatientModel p) {
    final _form = GlobalKey<FormState>();
    final _name = TextEditingController(text: p.name);
    String gender = p.gender ?? 'Female';
    final _age = TextEditingController(text: p.age?.toString() ?? '');
    final _phone = TextEditingController(text: p.phone);
    final _disease = TextEditingController(text: p.disease ?? '');
    String blood = p.bloodGroup ?? 'O+';
    String marital = p.maritalStatus ?? 'Single';
    final _notes = TextEditingController(text: p.notes ?? '');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => AnimatedPadding(
        duration: const Duration(milliseconds: 300),
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(
          builder: (ctx, setState) {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _form,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Edit Patient',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: _name,
                        decoration:
                        const InputDecoration(labelText: 'Full name'),
                        validator: (v) =>
                        v == null || v.trim().isEmpty ? 'Required' : null,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _age,
                              decoration:
                              const InputDecoration(labelText: 'Age'),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextFormField(
                              controller: _phone,
                              decoration:
                              const InputDecoration(labelText: 'Phone'),
                              keyboardType: TextInputType.phone,
                            ),
                          ),
                        ],
                      ),
                      TextFormField(
                        controller: _disease,
                        decoration: const InputDecoration(
                            labelText: 'Disease / Problem'),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: blood,
                              items: [
                                'O+',
                                'A+',
                                'B+',
                                'AB+',
                                'O-',
                                'A-',
                                'B-',
                                'AB-'
                              ]
                                  .map((e) => DropdownMenuItem(
                                  value: e, child: Text(e)))
                                  .toList(),
                              onChanged: (v) => setState(() => blood = v!),
                              decoration: const InputDecoration(
                                  labelText: 'Blood Group'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: marital,
                              items: ['Single', 'Married', 'Other']
                                  .map((e) => DropdownMenuItem(
                                  value: e, child: Text(e)))
                                  .toList(),
                              onChanged: (v) => setState(() => marital = v!),
                              decoration: const InputDecoration(
                                  labelText: 'Marital Status'),
                            ),
                          ),
                        ],
                      ),
                      const Align(
                        alignment: Alignment.centerLeft,
                        child: Text('Gender',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                      ),
                      Column(
                        children: ['Female', 'Male', 'Other']
                            .map(
                              (g) => RadioListTile<String>(
                            title: Text(g),
                            value: g,
                            groupValue: gender,
                            onChanged: (v) =>
                                setState(() => gender = v!),
                          ),
                        )
                            .toList(),
                      ),
                      TextFormField(
                        controller: _notes,
                        decoration:
                        const InputDecoration(labelText: 'Notes'),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.save),
                        onPressed: () async {
                          if (!_form.currentState!.validate()) return;
                          final updated = PatientModel(
                            id: p.id,
                            doctorId: p.doctorId,
                            name: _name.text.trim(),
                            gender: gender,
                            age: int.tryParse(_age.text.trim()),
                            phone: _phone.text.trim(),
                            disease: _disease.text.trim(),
                            bloodGroup: blood,
                            maritalStatus: marital,
                            notes: _notes.text.trim(),
                            createdAt: p.createdAt,
                          );
                          await prov.updatePatient(updated);
                          Navigator.pop(ctx);
                        },
                        label: const Text('Update'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF0FAF7C),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
