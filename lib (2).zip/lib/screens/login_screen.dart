import 'package:flutter/material.dart';
import 'package:physio_clinic_appointment/widgets/main_navigator.dart';
import 'package:provider/provider.dart';
import '../providers/doctor_provider.dart';
import '../providers/auth_provider.dart';
import '../models/doctor_model.dart';
import 'dashboard_screen.dart' hide AuthProvider;
import 'admin_doctors_screen.dart';
import 'package:lottie/lottie.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  DoctorModel? selectedDoctor;
  final _password = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Load doctors when screen initializes
    final docProv = Provider.of<DoctorProvider>(context, listen: false);
    docProv.loadDoctors();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0FAF7C), Color(0xFF2AB7A9)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const SizedBox(height: 8),
                SizedBox(
                  height: 120,
                  child: Lottie.asset('assets/lottie/success.json'),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Clinic Management',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),

                // Doctor Dropdown using Consumer
                Consumer<DoctorProvider>(
                  builder: (context, docProv, _) {
                   /* if (docProv.isLoading) {
                      return const Center(
                        child: CircularProgressIndicator(
                          color: Colors.white,
                        ),
                      );
                    }*/

                    final docs = docProv.doctors;

                    if (docs.isEmpty) {
                      return const Text(
                        'No doctors available. Please add a doctor first.',
                        style: TextStyle(color: Colors.white),
                      );
                    }

                    // Reset selectedDoctor if it no longer exists
                    if (selectedDoctor != null &&
                        !docs.any((d) => d.id == selectedDoctor!.id)) {
                      selectedDoctor = null;
                    }

                    return DropdownButtonFormField<int>(
                      value: selectedDoctor?.id,
                      hint: const Text('Select Doctor'),
                      items: docs
                          .map((d) => DropdownMenuItem<int>(
                        value: d.id,
                        child: Text(d.name),
                      ))
                          .toList(),
                      onChanged: (id) {
                        setState(() {
                          selectedDoctor =
                              docs.firstWhere((d) => d.id == id);
                        });
                      },
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        filled: true,
                      ),
                    );
                  },
                ),

                const SizedBox(height: 12),
                TextField(
                  controller: _password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    hintText: 'Password (any for demo)',
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),

                // Login Button
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          if (selectedDoctor == null) return;
                          Provider.of<AuthProvider>(context, listen: false)
                              .login(selectedDoctor!);
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const MainNavigator()),
                          );
                        },
                        child: const Text('Login'),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Admin Manage Doctors Button
                TextButton(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AdminDoctorsScreen()),
                    );
                    // Reload doctors after returning from admin screen
                    final docProv =
                    Provider.of<DoctorProvider>(context, listen: false);
                    docProv.loadDoctors();
                  },
                  child: const Text('Manage Doctors (Admin)'),
                ),

                const SizedBox(height: 8),
                const Text(
                  'Tip: Add a doctor using Manage Doctors then select to login.',
                  style: TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
