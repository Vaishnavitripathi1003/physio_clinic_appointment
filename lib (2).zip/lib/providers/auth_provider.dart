import 'package:flutter/material.dart';
import '../models/doctor_model.dart';

class AuthProvider with ChangeNotifier {
  DoctorModel? _currentDoctor;
  DoctorModel? get currentDoctor => _currentDoctor;

  void login(DoctorModel d) {
    _currentDoctor = d;
    notifyListeners();
  }

  void logout() {
    _currentDoctor = null;
    notifyListeners();
  }

  bool get isLoggedIn => _currentDoctor != null;
}
