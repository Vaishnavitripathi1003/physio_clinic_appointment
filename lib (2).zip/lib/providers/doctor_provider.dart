import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import '../models/doctor_model.dart'; // Ensure DoctorModel has 'id' field

class DoctorProvider with ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper();

  // Master list of all doctors loaded from the database
  List<DoctorModel> _doctors = [];
  List<DoctorModel> get doctors => _doctors;

  // List used for display, updated by search filter
  List<DoctorModel> _filteredDoctors = [];
  List<DoctorModel> get filteredDoctors => _filteredDoctors;

  // Future is not necessary here but good for consistency
  Future<void> loadDoctors() async {
    try {
      final rows = await _db.queryAll('doctors');
      _doctors = rows.map((r) => DoctorModel.fromMap(r)).toList();
      _filteredDoctors = _doctors; // Initialize filtered list with all doctors
    } catch (e) {
      // Handle error, e.g., print or log it
      debugPrint('Error loading doctors: $e');
      _doctors = [];
      _filteredDoctors = [];
    }
    notifyListeners();
  }

  Future<void> addDoctor(DoctorModel d) async {
    await _db.insert('doctors', d.toMap());
    await loadDoctors(); // Reload data after insertion
  }

  // Renamed to editDoctor for UI consistency
  Future<void> editDoctor(DoctorModel d) async {
    // We assume d.id is non-null for an update operation
    if (d.id != null) {
      await _db.update('doctors', d.toMap(), d.id!);
      await loadDoctors(); // Reload data after update
    }
  }

  Future<void> deleteDoctor(int id) async {
    await _db.delete('doctors', id);
    await loadDoctors(); // Reload data after deletion
  }

  // New method to handle filtering/searching logic
  void filterDoctors(String query) {
    if (query.isEmpty) {
      _filteredDoctors = _doctors; // Show all if query is empty
    } else {
      final lowerQuery = query.toLowerCase();
      _filteredDoctors = _doctors.where((doctor) {
        // Check doctor name or specialization
        return doctor.name.toLowerCase().contains(lowerQuery) ||
            (doctor.specialization?.toLowerCase().contains(lowerQuery) ?? false);
      }).toList();
    }
    notifyListeners();
  }
}