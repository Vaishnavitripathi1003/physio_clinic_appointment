import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import '../models/patient_model.dart';

class PatientProvider with ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper();
  List<PatientModel> _patients = [];
  List<PatientModel> get patients => _patients;

  Future loadPatients() async {
    final rows = await _db.queryAll('patients');
    _patients = rows.map((r) => PatientModel.fromMap(r)).toList();
    notifyListeners();
  }

  Future loadPatientsForDoctor(int doctorId) async {
    final rows = await _db.rawQuery('SELECT * FROM patients WHERE doctorId = ? ORDER BY id DESC', [doctorId]);
    _patients = rows.map((r) => PatientModel.fromMap(r)).toList();
    notifyListeners();
  }

  Future addPatient(PatientModel p) async {
    await _db.insert('patients', p.toMap());
    await loadPatients();
  }

  Future updatePatient(PatientModel p) async {
    await _db.update('patients', p.toMap(), p.id!);
    await loadPatients();
  }

  Future deletePatient(int id) async {
    await _db.delete('patients', id);
    await loadPatients();
  }
}
