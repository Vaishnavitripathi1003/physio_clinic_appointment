class Doctor {
  int? id;
  String name;
  String? specialization;
  String? phone;
  String? email;
  double? fee;
  int? experience;
  String? gender;
  String? bloodGroup;
  String? address;
  bool available;
  String? notes;

  Doctor({this.id, required this.name, this.specialization, this.phone, this.email, this.fee, this.experience, this.gender, this.bloodGroup, this.address, this.available = true, this.notes});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'specialization': specialization,
      'phone': phone,
      'email': email,
      'fee': fee,
      'experience': experience,
      'gender': gender,
      'bloodGroup': bloodGroup,
      'address': address,
      'available': available ? 1 : 0,
      'notes': notes,
    };
  }

  factory Doctor.fromMap(Map<String, dynamic> map) => Doctor(
    id: map['id'],
    name: map['name'],
    specialization: map['specialization'],
    phone: map['phone'],
    email: map['email'],
    fee: map['fee']?.toDouble(),
    experience: map['experience'],
    gender: map['gender'],
    bloodGroup: map['bloodGroup'],
    address: map['address'],
    available: (map['available'] ?? 1) == 1,
    notes: map['notes'],
  );
}
