class Appointment {
  int? id;
  int patientId;
  int doctorId;
  String datetime; // ISO string
  String? reason;
  String? status;

  Appointment({this.id, required this.patientId, required this.doctorId, required this.datetime, this.reason, this.status});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patientId': patientId,
      'doctorId': doctorId,
      'datetime': datetime,
      'reason': reason,
      'status': status,
    };
  }

  factory Appointment.fromMap(Map<String, dynamic> map) => Appointment(
    id: map['id'],
    patientId: map['patientId'],
    doctorId: map['doctorId'],
    datetime: map['datetime'],
    reason: map['reason'],
    status: map['status'],
  );
}
