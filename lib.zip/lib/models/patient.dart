class Patient {
  int? id;
  String name;
  String? phone;
  String? email;
  String? dob; // ISO string
  String? gender;
  String? bloodGroup;
  String? address;
  String? emergencyContact;
  String? notes;

  Patient({this.id, required this.name, this.phone, this.email, this.dob, this.gender, this.bloodGroup, this.address, this.emergencyContact, this.notes});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'email': email,
      'dob': dob,
      'gender': gender,
      'bloodGroup': bloodGroup,
      'address': address,
      'emergencyContact': emergencyContact,
      'notes': notes,
    };
  }

  factory Patient.fromMap(Map<String, dynamic> map) => Patient(
    id: map['id'],
    name: map['name'],
    phone: map['phone'],
    email: map['email'],
    dob: map['dob'],
    gender: map['gender'],
    bloodGroup: map['bloodGroup'],
    address: map['address'],
    emergencyContact: map['emergencyContact'],
    notes: map['notes'],
  );
}
