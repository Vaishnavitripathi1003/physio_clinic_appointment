import 'package:flutter/material.dart';

Widget labeledText(String label, String value) {
  return Row(
    children: [
      Text('$label: ', style: const TextStyle(fontWeight: FontWeight.bold)),
      Expanded(child: Text(value)),
    ],
  );
}
