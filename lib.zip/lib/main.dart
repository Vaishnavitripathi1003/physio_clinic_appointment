import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/patient_provider.dart';
import 'providers/doctor_provider.dart';
import 'providers/appointment_provider.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ClinicApp());
}

final Color primaryStart = Color(0xFF4C8BF5);
final Color primaryEnd = Color(0xFF6DD3B0);

class ClinicApp extends StatelessWidget {
  const ClinicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => PatientProvider()..loadPatients()),
        ChangeNotifierProvider(create: (_) => DoctorProvider()..loadDoctors()),
        ChangeNotifierProvider(create: (_) => AppointmentProvider()..loadAppointments()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Clinic Manager',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: primaryStart),
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
