import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/patient_provider.dart';
import '../models/patient.dart';

class PatientsScreen extends StatelessWidget {
  const PatientsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<PatientProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Patients')),
      body: FutureBuilder(
        future: prov.loadPatients(),
        builder: (context, snapshot) {
          final patients = prov.patients;
          if (patients.isEmpty) return const Center(child: Text('No patients'));

          return ListView.builder(
            itemCount: patients.length,
            itemBuilder: (context, i) {
              final p = patients[i];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(child: Text(p.name.substring(0,1).toUpperCase())),
                  title: Text(p.name),
                  subtitle: Text(p.phone ?? p.email ?? ''),
                  trailing: PopupMenuButton<String>(
                    onSelected: (s) async {
                      if (s == 'delete') await prov.deletePatient(p.id!);
                      if (s == 'edit') _showEditPatient(context, prov, p);
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: 'edit', child: Text('Edit')),
                      const PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => _showAddPatient(context, prov),
      ),
    );
  }

  void _showAddPatient(BuildContext context, PatientProvider prov) {
    final _formKey = GlobalKey<FormState>();
    final _name = TextEditingController();
    final _phone = TextEditingController();
    final _email = TextEditingController();
    final _address = TextEditingController();
    String gender = 'Female';
    String blood = 'O+';
    DateTime? dob;

    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(builder: (ctx, setState) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Add Patient', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => v==null||v.trim().isEmpty? 'Required' : null),
                  TextFormField(controller: _phone, decoration: const InputDecoration(labelText: 'Phone')),
                  TextFormField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
                  TextFormField(controller: _address, decoration: const InputDecoration(labelText: 'Address')),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: DropdownButtonFormField<String>(value: blood, items: ['O+','A+','B+','AB+','O-','A-','B-','AB-'].map((e)=>DropdownMenuItem(value: e,child: Text(e))).toList(), onChanged: (v)=>setState(()=>blood=v!), decoration: const InputDecoration(labelText: 'Blood Group'))),
                    const SizedBox(width: 8),
                    Expanded(child: ElevatedButton(onPressed: () async {
                      final dt = await showDatePicker(context: ctx, initialDate: DateTime(1990), firstDate: DateTime(1900), lastDate: DateTime.now());
                      if (dt != null) setState(()=>dob=dt);
                    }, child: Text(dob==null? 'Pick DOB' : dob!.toLocal().toString().split(' ')[0]))),
                  ]),
                  const SizedBox(height: 8),
                  Column(
                    children: ['Female','Male','Other'].map((g) => RadioListTile<String>(title: Text(g), value: g, groupValue: gender, onChanged: (v)=>setState(()=>gender=v!))).toList(),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () async {
                      if (!_formKey.currentState!.validate()) return;
                      await prov.addPatient(Patient(name: _name.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(), address: _address.text.trim(), gender: gender, bloodGroup: blood, dob: dob?.toIso8601String()));
                      Navigator.pop(ctx);
                    },
                    child: const Text('Save'),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  void _showEditPatient(BuildContext context, PatientProvider prov, Patient p) {
    final _formKey = GlobalKey<FormState>();
    final _name = TextEditingController(text: p.name);
    final _phone = TextEditingController(text: p.phone);
    final _email = TextEditingController(text: p.email);
    final _address = TextEditingController(text: p.address);
    String gender = p.gender ?? 'Female';
    String blood = p.bloodGroup ?? 'O+';
    DateTime? dob = p.dob!=null? DateTime.tryParse(p.dob!):null;

    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(builder: (ctx, setState) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Edit Patient', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => v==null||v.trim().isEmpty? 'Required' : null),
                  TextFormField(controller: _phone, decoration: const InputDecoration(labelText: 'Phone')),
                  TextFormField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
                  TextFormField(controller: _address, decoration: const InputDecoration(labelText: 'Address')),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: DropdownButtonFormField<String>(value: blood, items: ['O+','A+','B+','AB+','O-','A-','B-','AB-'].map((e)=>DropdownMenuItem(value: e,child: Text(e))).toList(), onChanged: (v)=>setState(()=>blood=v!), decoration: const InputDecoration(labelText: 'Blood Group'))),
                    const SizedBox(width: 8),
                    Expanded(child: ElevatedButton(onPressed: () async {
                      final dt = await showDatePicker(context: ctx, initialDate: dob ?? DateTime(1990), firstDate: DateTime(1900), lastDate: DateTime.now());
                      if (dt != null) setState(()=>dob=dt);
                    }, child: Text(dob==null? 'Pick DOB' : dob!.toLocal().toString().split(' ')[0]))),
                  ]),
                  const SizedBox(height: 8),
                  Column(
                    children: ['Female','Male','Other'].map((g) => RadioListTile<String>(title: Text(g), value: g, groupValue: gender, onChanged: (v)=>setState(()=>gender=v!))).toList(),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () async {
                      if (!_formKey.currentState!.validate()) return;
                      final updated = Patient(id: p.id, name: _name.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(), address: _address.text.trim(), gender: gender, bloodGroup: blood, dob: dob?.toIso8601String());
                      await prov.updatePatient(updated);
                      Navigator.pop(ctx);
                    },
                    child: const Text('Update'),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}
