import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/doctor_provider.dart';
import '../models/doctor.dart';

class DoctorsScreen extends StatelessWidget {
  const DoctorsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<DoctorProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Doctors')),
      body: FutureBuilder(
        future: prov.loadDoctors(),
        builder: (context, snapshot) {
          final doctors = prov.doctors;
          if (doctors.isEmpty) return const Center(child: Text('No doctors'));

          return ListView.builder(
            itemCount: doctors.length,
            itemBuilder: (context, i) {
              final d = doctors[i];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(child: Text(d.name.substring(0,1).toUpperCase())),
                  title: Text(d.name),
                  subtitle: Text('${d.specialization ?? ''} • ${d.experience!=null? '${d.experience} yrs' : ''}'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (s) async {
                      if (s == 'delete') await prov.deleteDoctor(d.id!);
                      if (s == 'edit') _showEditDoctor(context, prov, d);
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: 'edit', child: Text('Edit')),
                      const PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => _showAddDoctor(context, prov),
      ),
    );
  }

  void _showAddDoctor(BuildContext context, DoctorProvider prov) {
    final _formKey = GlobalKey<FormState>();
    final _name = TextEditingController();
    final _spec = TextEditingController();
    final _phone = TextEditingController();
    final _email = TextEditingController();
    final _address = TextEditingController();
    final _fee = TextEditingController();
    final _exp = TextEditingController();
    String gender = 'Female';
    String blood = 'O+';
    bool available = true;

    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(builder: (ctx, setState) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Add Doctor', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => v==null||v.trim().isEmpty? 'Required' : null),
                  TextFormField(controller: _spec, decoration: const InputDecoration(labelText: 'Specialization')),
                  TextFormField(controller: _phone, decoration: const InputDecoration(labelText: 'Phone')),
                  TextFormField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
                  TextFormField(controller: _address, decoration: const InputDecoration(labelText: 'Address')),
                  Row(children: [
                    Expanded(child: TextFormField(controller: _fee, decoration: const InputDecoration(labelText: 'Consultation fee'), keyboardType: TextInputType.number)),
                    const SizedBox(width: 8),
                    Expanded(child: TextFormField(controller: _exp, decoration: const InputDecoration(labelText: 'Experience (yrs)'), keyboardType: TextInputType.number)),
                  ]),
                  SwitchListTile(title: const Text('Available'), value: available, onChanged: (v)=>setState(()=>available=v)),
                  const SizedBox(height: 8),
                  Column(
                    children: ['Female','Male','Other'].map((g) => RadioListTile<String>(title: Text(g), value: g, groupValue: gender, onChanged: (v)=>setState(()=>gender=v!))).toList(),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: DropdownButtonFormField<String>(value: blood, items: ['O+','A+','B+','AB+','O-','A-','B-','AB-'].map((e)=>DropdownMenuItem(value: e,child: Text(e))).toList(), onChanged: (v)=>setState(()=>blood=v!), decoration: const InputDecoration(labelText: 'Blood Group'))),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () async {
                      if (!_formKey.currentState!.validate()) return;
                      await prov.addDoctor(Doctor(name: _name.text.trim(), specialization: _spec.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(), address: _address.text.trim(), fee: double.tryParse(_fee.text.trim()) ?? 0.0, experience: int.tryParse(_exp.text.trim()), gender: gender, bloodGroup: blood, available: available));
                      Navigator.pop(ctx);
                    },
                    child: const Text('Save'),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  void _showEditDoctor(BuildContext context, DoctorProvider prov, Doctor d) {
    final _formKey = GlobalKey<FormState>();
    final _name = TextEditingController(text: d.name);
    final _spec = TextEditingController(text: d.specialization);
    final _phone = TextEditingController(text: d.phone);
    final _email = TextEditingController(text: d.email);
    final _address = TextEditingController(text: d.address);
    final _fee = TextEditingController(text: d.fee?.toString() ?? '');
    final _exp = TextEditingController(text: d.experience?.toString() ?? '');
    String gender = d.gender ?? 'Female';
    String blood = d.bloodGroup ?? 'O+';
    bool available = d.available;

    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(builder: (ctx, setState) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Edit Doctor', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => v==null||v.trim().isEmpty? 'Required' : null),
                  TextFormField(controller: _spec, decoration: const InputDecoration(labelText: 'Specialization')),
                  TextFormField(controller: _phone, decoration: const InputDecoration(labelText: 'Phone')),
                  TextFormField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
                  TextFormField(controller: _address, decoration: const InputDecoration(labelText: 'Address')),
                  Row(children: [
                    Expanded(child: TextFormField(controller: _fee, decoration: const InputDecoration(labelText: 'Consultation fee'), keyboardType: TextInputType.number)),
                    const SizedBox(width: 8),
                    Expanded(child: TextFormField(controller: _exp, decoration: const InputDecoration(labelText: 'Experience (yrs)'), keyboardType: TextInputType.number)),
                  ]),
                  SwitchListTile(title: const Text('Available'), value: available, onChanged: (v)=>setState(()=>available=v)),
                  const SizedBox(height: 8),
                  Column(
                    children: ['Female','Male','Other'].map((g) => RadioListTile<String>(title: Text(g), value: g, groupValue: gender, onChanged: (v)=>setState(()=>gender=v!))).toList(),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: DropdownButtonFormField<String>(value: blood, items: ['O+','A+','B+','AB+','O-','A-','B-','AB-'].map((e)=>DropdownMenuItem(value: e,child: Text(e))).toList(), onChanged: (v)=>setState(()=>blood=v!), decoration: const InputDecoration(labelText: 'Blood Group'))),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () async {
                      if (!_formKey.currentState!.validate()) return;
                      final updated = Doctor(id: d.id, name: _name.text.trim(), specialization: _spec.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(), address: _address.text.trim(), fee: double.tryParse(_fee.text.trim()) ?? 0.0, experience: int.tryParse(_exp.text.trim()), gender: gender, bloodGroup: blood, available: available);
                      await prov.updateDoctor(updated);
                      Navigator.pop(ctx);
                    },
                    child: const Text('Update'),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}
