import 'package:flutter/material.dart';
import 'patients_screen.dart';
import 'doctors_screen.dart';
import 'appointments_screen.dart';
import 'prescriptions_screen.dart';
import 'invoices_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final gradient = const LinearGradient(colors: [Color(0xFF4C8BF5), Color(0xFF6DD3B0)], begin: Alignment.topLeft, end: Alignment.bottomRight);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: gradient),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Clinic Manager', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                    IconButton(icon: const Icon(Icons.settings, color: Colors.white), onPressed: () {})
                  ],
                ),
              ),
              Expanded(
                child: GridView.count(
                  padding: const EdgeInsets.all(16),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  children: [
                    _Tile(title: 'Patients', icon: Icons.person, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PatientsScreen()))),
                    _Tile(title: 'Doctors', icon: Icons.medical_services, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DoctorsScreen()))),
                    _Tile(title: 'Appointments', icon: Icons.event, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppointmentsScreen()))),
                    _Tile(title: 'Prescriptions', icon: Icons.receipt_long, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrescriptionsScreen()))),
                    _Tile(title: 'Invoices', icon: Icons.payment, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoicesScreen()))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  const _Tile({required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 6,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(colors: [Colors.white, Colors.white70], begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 48, color: Colors.indigo),
                const SizedBox(height: 8),
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
