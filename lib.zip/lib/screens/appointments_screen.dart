import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/appointment_provider.dart';
import '../providers/patient_provider.dart';
import '../providers/doctor_provider.dart';
import '../models/appointment.dart';

class AppointmentsScreen extends StatelessWidget {
  const AppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<AppointmentProvider>(context);
    final patientProv = Provider.of<PatientProvider>(context);
    final doctorProv = Provider.of<DoctorProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Appointments')),
      body: FutureBuilder(
        future: Future.wait([prov.loadAppointments(), patientProv.loadPatients(), doctorProv.loadDoctors()]),
        builder: (context, snapshot) {
          final appts = prov.appointments;
          if (appts.isEmpty) return const Center(child: Text('No appointments'));
          return ListView.builder(
            itemCount: appts.length,
            itemBuilder: (context, i) {
              final a = appts[i];
              return ListTile(
                title: Text('Appointment #${a.id}'),
                subtitle: Text('${a.datetime} • ${a.reason ?? ''}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () async => await prov.deleteAppointment(a.id!),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => _showAddAppointment(context, prov, patientProv, doctorProv),
      ),
    );
  }

  void _showAddAppointment(BuildContext context, AppointmentProvider prov, PatientProvider pProv, DoctorProvider dProv) {
    final _reason = TextEditingController();
    int? selectedPatient;
    int? selectedDoctor;
    DateTime selectedDate = DateTime.now();
    TimeOfDay selectedTime = TimeOfDay.now();
    String status = 'Scheduled';

    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(builder: (ctx, setState) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Add Appointment', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(hint: const Text('Select patient'), items: pProv.patients.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v)=>setState(()=>selectedPatient=v)),
                DropdownButtonFormField<int>(hint: const Text('Select doctor'), items: dProv.doctors.map((d) => DropdownMenuItem(value: d.id, child: Text(d.name))).toList(), onChanged: (v)=>setState(()=>selectedDoctor=v)),
                TextField(controller: _reason, decoration: const InputDecoration(labelText: 'Reason')),
                Row(children: [
                  Expanded(child: ElevatedButton(onPressed: () async { final dt = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime(2000), lastDate: DateTime(2100)); if (dt!=null) setState(()=>selectedDate=dt); }, child: Text('Date: \${selectedDate.toLocal().toString().split(' ')[0]}'))),
                  const SizedBox(width: 8),
                  Expanded(child: ElevatedButton(onPressed: () async { final t = await showTimePicker(context: ctx, initialTime: selectedTime); if (t!=null) setState(()=>selectedTime=t); }, child: Text('Time: \${selectedTime.format(ctx)}'))),
                ]),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(value: status, items: ['Scheduled','Completed','Cancelled'].map((s)=>DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v)=>setState(()=>status=v!)),
                const SizedBox(height: 12),
                ElevatedButton(onPressed: () async {
                  if (selectedPatient==null || selectedDoctor==null) return;
                  final dtIso = DateTime(selectedDate.year, selectedDate.month, selectedDate.day, selectedTime.hour, selectedTime.minute).toIso8601String();
                  await prov.addAppointment(Appointment(patientId: selectedPatient!, doctorId: selectedDoctor!, datetime: dtIso, reason: _reason.text, status: status));
                  Navigator.pop(ctx);
                }, child: const Text('Add')),
              ],
            ),
          );
        }),
      ),
    );
  }
}
