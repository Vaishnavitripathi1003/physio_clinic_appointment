import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/patient.dart';

class PatientProvider with ChangeNotifier {
  final DBHelper _db = DBHelper();
  List<Patient> _patients = [];
  List<Patient> get patients => _patients;

  Future loadPatients() async {
    final rows = await _db.queryAll('patients');
    _patients = rows.map((r) => Patient.fromMap(r)).toList();
    notifyListeners();
  }

  Future addPatient(Patient p) async {
    await _db.insert('patients', p.toMap());
    await loadPatients();
  }

  Future updatePatient(Patient p) async {
    await _db.update('patients', p.toMap(), p.id!);
    await loadPatients();
  }

  Future deletePatient(int id) async {
    await _db.delete('patients', id);
    await loadPatients();
  }
}
