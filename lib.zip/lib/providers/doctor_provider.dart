import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/doctor.dart';

class DoctorProvider with ChangeNotifier {
  final DBHelper _db = DBHelper();
  List<Doctor> _doctors = [];
  List<Doctor> get doctors => _doctors;

  Future loadDoctors() async {
    final rows = await _db.queryAll('doctors');
    _doctors = rows.map((r) => Doctor.fromMap(r)).toList();
    notifyListeners();
  }

  Future addDoctor(Doctor d) async {
    await _db.insert('doctors', d.toMap());
    await loadDoctors();
  }

  Future updateDoctor(Doctor d) async {
    await _db.update('doctors', d.toMap(), d.id!);
    await loadDoctors();
  }

  Future deleteDoctor(int id) async {
    await _db.delete('doctors', id);
    await loadDoctors();
  }
}
