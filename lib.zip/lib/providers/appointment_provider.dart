import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/appointment.dart';

class AppointmentProvider with ChangeNotifier {
  final DBHelper _db = DBHelper();
  List<Appointment> _appointments = [];
  List<Appointment> get appointments => _appointments;

  Future loadAppointments() async {
    final rows = await _db.queryAll('appointments');
    _appointments = rows.map((r) => Appointment.fromMap(r)).toList();
    notifyListeners();
  }

  Future addAppointment(Appointment a) async {
    await _db.insert('appointments', a.toMap());
    await loadAppointments();
  }

  Future updateAppointment(Appointment a) async {
    await _db.update('appointments', a.toMap(), a.id!);
    await loadAppointments();
  }

  Future deleteAppointment(int id) async {
    await _db.delete('appointments', id);
    await loadAppointments();
  }
}
